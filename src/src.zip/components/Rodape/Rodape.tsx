export default function Rodape() {
    return (
        <footer className="rodape">
            <h2>FRONT-END</h2>
            <p>Projeto CP6</p>
        </footer>
    )
}
