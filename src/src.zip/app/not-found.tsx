
export default function NotFound() {
  return (
<div className="not-found-page">
      <h1>404</h1>
      <h2>Página não encontrada...</h2>
      <p>
        O recurso que você estava tentando acessar não está mais disponível.
      </p>
    </div>
  );
}
