import Spinner from "@/components/Spinner/Spinner";

export default function Loading() {
  return (
  <div>
    <Spinner/>
  </div>
  )
}
